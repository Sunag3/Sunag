from django.apps import AppConfig


class TutorialConfig(AppConfig):
    name = 'tutorial'
